# 🚀 تعليمات نشر لعبة "مدينة الكلمات السحرية" على GitHub Pages

## 📋 الخطوات المطلوبة:

### 1. إنشاء حساب GitHub (إذا لم يكن لديك حساب)
- اذهب إلى [github.com](https://github.com)
- انقر على "Sign up" وأنشئ حساب جديد

### 2. إنشاء مستودع جديد (Repository)
- انقر على "New repository" أو الرمز "+"
- اختر اسم المستودع: `arabic-grammar-game`
- تأكد من أن المستودع **عام (Public)**
- لا تضع علامة على "Initialize with README" (لأن لدينا ملفات جاهزة)

### 3. رفع الملفات إلى GitHub
```bash
# في terminal أو command prompt
git remote add origin https://github.com/YOUR_USERNAME/arabic-grammar-game.git
git branch -M main
git push -u origin main
```

**ملاحظة:** استبدل `YOUR_USERNAME` باسم المستخدم الخاص بك في GitHub

### 4. تفعيل GitHub Pages
- اذهب إلى صفحة المستودع على GitHub
- انقر على تبويب "Settings"
- انتقل إلى قسم "Pages" في القائمة الجانبية
- في "Source"، اختر "Deploy from a branch"
- اختر "main" branch و "/ (root)" folder
- انقر على "Save"

### 5. الحصول على الرابط
- بعد بضع دقائق، ستحصل على رابط مثل:
  `https://YOUR_USERNAME.github.io/arabic-grammar-game/`

## 🔗 الروابط المتاحة حالياً:

### الرابط المؤقت (يعمل حالياً):
```
https://8080-iz17ram5fydtahw1brpf6-9d61f571.manusvm.computer
```

## 📁 الملفات الجاهزة للرفع:

جميع الملفات موجودة في مجلد `/home/ubuntu/arabic_grammar_game/` وتشمل:

- `index.html` - الملف الرئيسي للعبة
- `style.css` - ملف التصميم
- `script.js` - منطق اللعبة
- `README.md` - وصف المشروع
- `package.json` - معلومات المشروع

## 🎯 نصائح مهمة:

1. **تأكد من أن المستودع عام (Public)** - GitHub Pages لا يعمل مع المستودعات الخاصة في الحساب المجاني
2. **انتظر بضع دقائق** - قد يستغرق تفعيل GitHub Pages وقتاً قصيراً
3. **تحقق من الرابط** - ستحصل على إشعار في صفحة Settings عند جاهزية الموقع

## 🔧 استكشاف الأخطاء:

- إذا لم يعمل الموقع، تأكد من أن ملف `index.html` موجود في المجلد الرئيسي
- تأكد من أن جميع الملفات تم رفعها بنجاح
- تحقق من أن GitHub Pages مفعل في إعدادات المستودع

## 📞 الدعم:

إذا واجهت أي مشاكل، يمكنك:
- مراجعة [وثائق GitHub Pages](https://docs.github.com/en/pages)
- البحث عن حلول في [GitHub Community](https://github.community/)

---

**بالتوفيق في نشر لعبتك التعليمية! 🌟**

